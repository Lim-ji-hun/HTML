

alert("test.js. 파일임");
document.write("외부 파일 로드");
console.log("페이지에 표시");
